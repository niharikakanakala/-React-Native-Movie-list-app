import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react-native';
import App from './App';

test('Adding a movie', () => {
    const { getByText, getByPlaceholderText } = render(<App />);
  
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
  
    fireEvent.changeText(titleInput, 'Test Movie');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    expect(getByText('Test Movie')).toBeTruthy();
  });

test('Editing a movie', () => {
    const { getByText, getByPlaceholderText } = render(<App />);
  
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
  
    fireEvent.changeText(titleInput, 'Test Movie');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    const editButton = getByText('Edit');
    fireEvent.press(editButton);
  
    const saveButton = getByText('Save');
    fireEvent.press(saveButton);
  
    expect(getByText('Test Movie')).toBeTruthy();
  });

test('Removing a movie', () => {
    const { getByText, getByPlaceholderText, queryByText } = render(<App />);
  
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
  
    fireEvent.changeText(titleInput, 'Test Movie');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    const removeButton = getByText('Remove');
    fireEvent.press(removeButton);
  
    expect(queryByText('Test Movie')).toBeNull();
  });

  test('Searching for a movie', () => {
    const { getByText, getByPlaceholderText } = render(<App />);
  
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
  
    // Add a movie
    fireEvent.changeText(titleInput, 'Test Movie');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    // Clear the inputs and search for the movie
    fireEvent.changeText(titleInput, '');
    fireEvent.changeText(timeInput, '');
    
    const searchInput = getByPlaceholderText('Search by Title');
    fireEvent.changeText(searchInput, 'Test Movie');
  
    expect(getByText('Test Movie')).toBeTruthy();
  });
  
  test('Sorting movies by title', () => {
    const { getByTestId, getByText, getByPlaceholderText } = render(<App />);
  
    // Find the input fields and buttons
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
    const sortButton = getByTestId('sort-button');
  
    // Add movies with different titles
    fireEvent.changeText(titleInput, 'Movie C');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    fireEvent.changeText(titleInput, 'Movie A');
    fireEvent.changeText(timeInput, '12:00');
    fireEvent.press(addButton);
  
    fireEvent.changeText(titleInput, 'Movie B');
    fireEvent.changeText(timeInput, '13:45');
    fireEvent.press(addButton);
  
    // Click the sort button to sort movies by title in ascending order
    fireEvent.press(sortButton);
  
    // Check if the movies are displayed in ascending order
    const movieList = [
      getByText('Movie A'),
      getByText('Movie B'),
      getByText('Movie C'),
    ];
  
    expect(movieList[0]).toBeTruthy();
    expect(movieList[1]).toBeTruthy();
    expect(movieList[2]).toBeTruthy();
  
    // Click the sort button again to sort movies by title in descending order
    fireEvent.press(sortButton);
  
    // Check if the movies are displayed in descending order
    const reverseMovieList = [
      getByText('Movie C'),
      getByText('Movie B'),
      getByText('Movie A'),
    ];
  
    expect(reverseMovieList[0]).toBeTruthy();
    expect(reverseMovieList[1]).toBeTruthy();
    expect(reverseMovieList[2]).toBeTruthy();
  });
  
  test('Editing and saving a movie', () => {
    const { getByText, getByPlaceholderText } = render(<App />);
  
    // Find the input fields and buttons
    const titleInput = getByPlaceholderText('Movie Title');
    const timeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const addButton = getByText('Add');
  
    // Add a movie
    fireEvent.changeText(titleInput, 'Test Movie');
    fireEvent.changeText(timeInput, '14:30');
    fireEvent.press(addButton);
  
    // Edit the added movie
    fireEvent.press(getByText('Edit'));
  
    const editedTitleInput = getByPlaceholderText('Movie Title');
    const editedTimeInput = getByPlaceholderText('Movie Time (HH:MM)');
    const saveButton = getByText('Save');
  
    // Edit the title and time
    fireEvent.changeText(editedTitleInput, 'Edited Movie');
    fireEvent.changeText(editedTimeInput, '3:45:53'); // Match the time format in your component
  
    // Save the edited movie
    fireEvent.press(saveButton);
  
    // Check if the movie details are updated
    expect(getByText('Edited Movie')).toBeTruthy();
    
  });

  test('Toggle Sort Order', () => {
    const { getByTestId } = render(<App />);
    
    // Get the initial sort order text
    const sortButton = getByTestId('sort-button');
    const initialSortOrder = sortButton.children[0].props.children; // Extract text content
    
    // Click the sort button to toggle the sort order
    fireEvent.press(sortButton);
    
    // Get the sort order text after clicking
    const newSortButton = getByTestId('sort-button');
    const newSortOrder = newSortButton.children[0].props.children; // Extract text content
    
    // Verify that the sort order has toggled
    expect(initialSortOrder).not.toBe(newSortOrder);
  })

  describe('Movie Form', () => {
    it('should allow adding a new movie and editing an existing movie', async () => {
      const { getByTestId, getByText, getByPlaceholderText } = render(<App />);
  
      // Find the movie title input field
      const movieTitleInput = getByTestId('movie-title-input');
      // Find the movie time input field
      const movieTimeInput = getByTestId('movie-time');
      // Find the add movie button
      const addMovieButton = getByTestId('add-movie-button');
  
      // Fill in the movie title and time and add a new movie
      fireEvent.changeText(movieTitleInput, 'Sample Movie');
      fireEvent.changeText(movieTimeInput, '14:30');
      fireEvent.press(addMovieButton);
  
      // Wait for the new movie to appear in the list (adjust the timeout as needed)
      await waitFor(() => getByText('Sample Movie'));
  
      // Find the edit button for the newly added movie
      const editButton = getByText('Edit');
      fireEvent.press(editButton);
  
      // Verify that the edit mode UI is displayed
      const saveButton = getByText('Save');
      expect(saveButton).toBeTruthy();
  
      // Find the title and time inputs in edit mode
      const editedMovieTitleInput = getByPlaceholderText('Movie Title');
      const editedMovieTimeInput = getByPlaceholderText('Movie Time (HH:MM)');
  
      // Edit the movie title and time
      fireEvent.changeText(editedMovieTitleInput, 'Edited Movie');
      fireEvent.changeText(editedMovieTimeInput, '15:00');
  
      // Click the save button to save the changes
      fireEvent.press(saveButton);
  
      // Verify that the edited movie details are displayed in the list
      expect(getByText('Edited Movie')).toBeTruthy();
    });
  });
  
  
  
  
  
  
