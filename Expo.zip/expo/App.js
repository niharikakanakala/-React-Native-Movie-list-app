import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';

const App = () => {
  const [movies, setMovies] = useState([]);
  const [movieTitle, setMovieTitle] = useState('');
  const [movieTime, setMovieTime] = useState(new Date()); // Initialize with the current time
  const [editMode, setEditMode] = useState(false);
  const [editedMovieId, setEditedMovieId] = useState(null);
  const [editedMovieTitle, setEditedMovieTitle] = useState('');
  const [editedMovieTime, setEditedMovieTime] = useState(new Date());
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState('asc'); // 'asc' for ascending, 'desc' for descending
  const [sortField, setSortField] = useState('title'); // 'title' or 'time'

  const addMovie = () => {
    if (movieTitle.trim() !== '') {
      setMovies([
        ...movies,
        { id: Date.now(), title: movieTitle, time: movieTime },
      ]);
      setMovieTitle('');
      setMovieTime(new Date());
    }
  };

  const editMovie = (movieId) => {
    setEditMode(true);
    setEditedMovieId(movieId);
    const movieToEdit = movies.find((movie) => movie.id === movieId);
    setEditedMovieTitle(movieToEdit.title);
    setEditedMovieTime(new Date(movieToEdit.time)); // Set the time to the original time of the movie
  };

  const saveEditedMovie = () => {
    const updatedMovies = movies.map((movie) =>
      movie.id === editedMovieId
        ? { ...movie, title: editedMovieTitle, time: editedMovieTime }
        : movie
    );
    setMovies(updatedMovies);
    setEditMode(false);
    setEditedMovieId(null);
    setEditedMovieTitle('');
  };

  const removeMovie = (movieId) => {
    const updatedMovies = movies.filter((movie) => movie.id !== movieId);
    setMovies(updatedMovies);
    setEditMode(false);
    setEditedMovieId(null);
    setEditedMovieTitle('');
    setEditedMovieTime(new Date());
  };

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Movie List</Text>
      <View style={styles.inputContainer}>
        {editMode ? (
          <>
            <TextInput
              style={styles.input}
              value={editedMovieTitle}
              onChangeText={(text) => setEditedMovieTitle(text)}
              placeholder="Movie Title"
            />
            <TextInput
              style={styles.input}
              value={editedMovieTime.toLocaleTimeString()}
              onChangeText={(text) => {
                const newTime = new Date(editedMovieTime);
                newTime.setHours(text.split(':')[0]);
                newTime.setMinutes(text.split(':')[1]);
                setEditedMovieTime(newTime);
              }}
             placeholder="Movie Time (HH:MM)"
            />
            <TouchableOpacity style={styles.saveButton} onPress={saveEditedMovie}>
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <TextInput
              style={styles.input}
              placeholder="Movie Title"
              testID ="movie-title-input"
              value={movieTitle}
              onChangeText={(text) => setMovieTitle(text)}
            />
            <TextInput
              style={styles.input}
              placeholder="Movie Time (HH:MM)"
              testID="movie-time"
              value={movieTime.toLocaleTimeString().substring(0, 5)}
              onChangeText={(text) => {
                const newTime = new Date(movieTime);
                newTime.setHours(text.split(':')[0]);
                newTime.setMinutes(text.split(':')[1]);
                setMovieTime(newTime);
              }}
            />
            <TouchableOpacity style={styles.addButton} testID='add-movie-button' onPress={addMovie}>
              <Text style={styles.addButtonText}>Add</Text>
            </TouchableOpacity>
          </>
        )
        }
      </View>
      <View style={styles.searchAndSortContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by Title"
          value={searchQuery}
          onChangeText={(text) => setSearchQuery(text)}
        />
        <TouchableOpacity
          style={styles.sortButton}
          onPress={toggleSortOrder}
          testID="sort-button" // Add this
        >
          <Text style={styles.sortButtonText}>
            Sort {sortField === 'title' ? 'Title' : 'Time'}{' '}
            {sortOrder === 'asc' ? '↑' : '↓'}
          </Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={movies
          .filter((movie) =>
             movie.title.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .sort((a, b) => {
            if (sortField === 'title') {
              const compareResult = a.title.localeCompare(b.title);
              return sortOrder === 'asc' ? compareResult : -compareResult;
            } else if (sortField === 'time') {
              const timeA = new Date(a.time);
              const timeB = new Date(b.time);

              if (sortOrder === 'asc') {
                return timeA - timeB;
              } else {
                return timeB - timeA;
              }
            }
            return 0;
          })}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.movieItem}>
            <Text>{item.title}</Text>
            <Text testID="movie-time">{item.time.toLocaleTimeString()}</Text>
            <View style={styles.buttonsContainer}>
              {editMode && editedMovieId === item.id ? (
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => {
                    setEditMode(false);
                    setEditedMovieId(null);
                    setEditedMovieTitle('');
                    setEditedMovieTime(new Date());
                  }}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  style={styles.editButton}
                  onPress={() => editMovie(item.id)}
                >
                  <Text style={styles.editButtonText}>Edit</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={styles.removeButton}
                onPress={() => removeMovie(item.id)}
              >
                <Text style={styles.removeButtonText}>Remove</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F0F0F0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    paddingLeft: 8,
    backgroundColor: 'white',
    borderRadius: 5,
  },
  addButton: {
    backgroundColor: 'blue',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
    marginLeft: 8,
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  saveButton: {
    backgroundColor: 'green',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
    marginLeft: 8,
  },
  saveButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  movieItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginBottom: 8,
    borderRadius: 5,
    elevation: 2,
  },
  buttonsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editButton: {
    backgroundColor: 'blue',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 5,
    marginRight: 8,
  },
  editButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  removeButton: {
    backgroundColor: 'red',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 5,
  },
  removeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: 'gray',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 5,
    marginRight: 8,
  },
  cancelButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  searchAndSortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    borderColor: 'gray',
    paddingLeft: 8,
    backgroundColor: 'white',
    borderRadius: 5,
    marginRight: 8,
  },
  sortButton: {
    backgroundColor: 'blue',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
  },
  sortButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default App;

